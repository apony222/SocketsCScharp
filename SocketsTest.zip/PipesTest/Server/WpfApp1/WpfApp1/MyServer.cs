﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class MyServer
    {
        private TcpListener serverSocket;
        private List<TcpClient> connectedClients;
        private CancellationTokenSource cts;

        public void StartServer()
        {
            try
            {
                // Start listening for incoming connections
                IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
                int port = 8888;
                serverSocket = new TcpListener(ipAddress, port);
                serverSocket.Start();

                Debug.WriteLine("Server started. Waiting for a connection...");

                connectedClients = new List<TcpClient>();
                cts = new CancellationTokenSource();

                // Start the server in a background thread
                Task.Run(() => AcceptConnections(cts.Token));
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error: " + ex.Message);
            }
        }

        public void SendToAllClients(string message)
        {
            foreach (TcpClient client in connectedClients)
            {
                try
                {
                    NetworkStream stream = client.GetStream();
                    byte[] buffer = Encoding.UTF8.GetBytes(message);
                    stream.Write(buffer, 0, buffer.Length);
                    Debug.WriteLine($"Message sent to client: {message}");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Error sending message to client: {ex.Message}");
                }
            }
        }

        public void StopServer()
        {
            cts?.Cancel();
            serverSocket?.Stop();
            Debug.WriteLine("Server stopped.");
        }

        private async void AcceptConnections(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    TcpClient client = await serverSocket.AcceptTcpClientAsync(); // Accept incoming connection asynchronously
                    connectedClients.Add(client); // Add the connected client to the list
                    Debug.WriteLine("Connected to client.");

                    // Start handling messages from this client in a separate thread
                    Task.Run(() => HandleClientMessages(client, cancellationToken));
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Error accepting connection: " + ex.Message);
                }
            }
        }

        private async void HandleClientMessages(TcpClient client, CancellationToken cancellationToken)
        {
            try
            {
                NetworkStream stream = client.GetStream();
                byte[] buffer = new byte[256];

                while (!cancellationToken.IsCancellationRequested)
                {
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length, cancellationToken);
                    if (bytesRead == 0)
                        break; // Connection closed by the client

                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    Debug.WriteLine($"Message received from client: {message}");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error handling client messages: {ex.Message}");
            }
        }
    }
}
