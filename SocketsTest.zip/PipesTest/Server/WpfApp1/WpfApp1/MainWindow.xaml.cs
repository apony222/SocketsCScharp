﻿using System.Diagnostics;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics.Metrics;
using System.IO;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        MyServer myServer = new MyServer();

        private void b_StartServer_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Start Server");
            myServer.StartServer();
        }


        private void b_SendCommand_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Send to Clients");
            myServer.SendToAllClients("hallo clients");

        }

        private void b_StopServer_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Stop Server");
            myServer.StopServer();

        }
    }
}