﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class MyClient
    {
        private TcpClient tcpClient;

        public async Task ConnectToServerAsync()
        {
            try
            {
                tcpClient = new TcpClient();
                await tcpClient.ConnectAsync("127.0.0.1", 8888); // Anpassen der Ziel-IP und des Ports
                Debug.WriteLine("Connected to server.");

                // Start handling messages from the server in a separate thread
                Task.Run(() => HandleServerMessages());
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error connecting to server: " + ex.Message);
            }
        }

        public async Task SendRequestAsync(string request)
        {
            try
            {
                if (tcpClient == null || !tcpClient.Connected)
                {
                    Debug.WriteLine("Error sending request: Client not connected.");
                    return;
                }

                NetworkStream stream = tcpClient.GetStream();
                byte[] requestBuffer = Encoding.UTF8.GetBytes(request);
                await stream.WriteAsync(requestBuffer, 0, requestBuffer.Length);
                Debug.WriteLine("Request sent to server: " + request);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error sending request: " + ex.Message);
            }
        }

        private async void HandleServerMessages()
        {
            try
            {
                NetworkStream stream = tcpClient.GetStream();
                byte[] buffer = new byte[256];

                while (true)
                {
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    if (bytesRead == 0)
                    {
                        Debug.WriteLine("Server closed the connection.");
                        break;
                    }

                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    Debug.WriteLine($"Message received from server: {message}");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error handling server messages: {ex.Message}");
            }
        }

        public void Disconnect()
        {
            tcpClient?.Close();
            Debug.WriteLine("Disconnected from server.");
        }
    }
}